const USER_ACTION_TYPES = {
    SET_CURRENT_USER: 'user/SET_CURRENT_USER',
  };
  
  export default USER_ACTION_TYPES;